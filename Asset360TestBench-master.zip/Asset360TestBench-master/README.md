# Asset360TestBench
PLEASE HARDCODE ROWS, COLUMNS, N IN schema.json.

Uses PySpark for distributed processing.
Please specify number of executors in schema.json.

Testbench for Asset360 page

CURRENTLY SUPPORTS THE FOLLOWING DATATYPES WITH SELECTED DISTRIBUTIONS:-
1) INT (UNIFORM DISTRIBUTION)
2) FLOAT (NORMAL DISTRIBUTION)
3) STRING (REGEX HARDCODED)
4) BOOLEAN



RUN python main.py for output
